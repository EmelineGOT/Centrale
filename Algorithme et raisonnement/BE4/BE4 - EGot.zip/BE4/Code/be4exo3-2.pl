pert(Debut):-

Debut=[A,B,C,D,E,F,G,H,I,J],

Debut::0..100,


A+5#=<B,A+5#=<C,A+5#=<D,
B+4#=<E,
C+3#=<F,C+3#=<G,
D+2#=<F,
E+1#=<H,
F+5#=<I,
G+4#=<I,
H+3#=<J,
I+2#=<J,

J#=15.


