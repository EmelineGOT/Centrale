import math;
N=20

for x in range(1,N+1):
    print('{0:2d} {1:3d} {2:4f}'.format(x,x*x,math.sqrt(x)))  #On imprime le tableau avec les différentes valeurs des calculs que l'on souhaite obtenir
    

