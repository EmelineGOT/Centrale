a=int(input('Donner un entier:'))	 #On demande l'entier a
if (a%2==0):						     #Si le reste de la division euclidienne de a par 2 est nul...
    print(a,"est pair.")			     #...L'entier est pair
else:
    print(a,"est impair.")			 #Sinon l'entier est impair
